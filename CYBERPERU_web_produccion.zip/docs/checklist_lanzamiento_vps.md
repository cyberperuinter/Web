# Checklist de lanzamiento — CYBER PERÚ (VPS Ubuntu 22.04)

## A) Antes de publicar (15 min)
- [ ] VPS creado (Ubuntu 22.04) y acceso por SSH
- [ ] Puertos: 22 abierto; 8000 abierto (temporal)
- [ ] Proyecto subido a: /opt/cyberperu/
- [ ] Python venv creado e instalado requirements

## B) Prueba técnica (10 min)
1) Salud:
- [ ] http://IP:8000/health devuelve {"ok": true}

2) Web:
- [ ] http://IP:8000 abre landing
- [ ] Puedes registrar usuario (register)
- [ ] Entras al dashboard (login)

3) Menú:
- [ ] Agrega 3 productos (dashboard)

4) Ubicación base (auto-zona):
- [ ] En dashboard -> “Ubicación & Delivery”
- [ ] Coloca lat/lng base del negocio (puedes sacarlo desde Google Maps)
- [ ] Guarda

## C) Prueba WhatsApp (demo webhook) (10 min)
En tu PC, usa curl o Postman:

### 1) Hola
POST http://IP:8000/webhooks/whatsapp
JSON:
{
  "from":"+51990000000",
  "text":"hola",
  "restaurant_id": 1
}

### 2) Pedido (sin GPS)
Envía:
- "3" -> menú
- "1" -> agrega producto
- "confirmar"
- "delivery"
- dirección texto
Si no detecta zona, te pedirá pin/link.

### 3) Pedido con GPS (recomendado)
POST con location:
{
  "from":"+51990000000",
  "text":"mi ubicacion",
  "restaurant_id":1,
  "location":{"lat":-12.2750,"lng":-76.8660}
}
✅ Debe calcular delivery y zona automáticamente.

### 4) Link Google Maps (sin payload)
En "text" manda un link que contenga @lat,lng (ejemplo):
https://www.google.com/maps/@-12.2750,-76.8660,17z

## D) Producción (no se cae)
- [ ] Configura systemd (ver docs/vps_ubuntu_deploy.md)
- [ ] Uvicorn en 127.0.0.1:8000
- [ ] (Opcional) Cuando compres dominio: proxy HTTPS con Caddy/Nginx

## E) Checklist de ventas (para cerrar rápido)
- [ ] Mensajes de cierre listos: docs/ventas_whatsapp_cyberperu.md
- [ ] Demo en vivo: landing + dashboard + 1 pedido con GPS
- [ ] Oferta PRO: S/69 / mes
- [ ] Oferta ELITE: S/99 / mes
