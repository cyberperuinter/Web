# Marca — CYBER PERÚ

Nombre: CYBER PERÚ
Tagline: "Tu WhatsApp trabajando por ti"
Colores:
- Fondo: #0B0F14
- Verde: #22C55E
- Azul: #38BDF8
- Amarillo: #FACC15

Zonas Lurín precargadas:
- Lurín Centro (S/5)
- Julio C. Tello (S/6)
- Mamacona / Las Flores (S/7)
- Puente San Luis / Boza (S/7)

Archivos de datos:
- data/lurin_zones.json
- data/address_presets_lurin.json
