# Flujo definitivo WhatsApp (Producción) – Pollerías y Restaurantes

## Entrada “hola / menu”
👋 ¡Hola! Bienvenido a *{NOMBRE_NEGOCIO}* 🍗  
¿Qué deseas hacer?  
1️⃣ Ver menú  
2️⃣ Promos de hoy  
3️⃣ Hacer pedido  
4️⃣ Ubicación y horarios  
5️⃣ Hablar con un asesor

## Menú
📋 *MENÚ*  
1. 1 Pollo — S/48.00  
2. 1/2 Pollo — S/28.00  
3. Papas fam. — S/12.00  
4. Ensalada — S/8.00  
5. Gaseosa 1.5L — S/10.00  
Responde con el *número* para agregar. Escribe *confirmar* para continuar.

## Carrito
✅ Agregado: *{ITEM}*  
🧾 Total: *S/{TOTAL}*  
¿Agregar más? (número / confirmar)

## Pedido rápido (frecuentes)
🤖 ¿Deseas pedir lo mismo de la última vez?
1️⃣ Sí
2️⃣ No

## Delivery / recojo
📦 ¿Cómo deseas tu pedido?
1️⃣ Delivery
2️⃣ Recojo

## Zonas (delivery)
📍 ¿Distrito?
1️⃣ Miraflores (S/5)
2️⃣ Surco (S/7)
3️⃣ San Borja (S/6)
4️⃣ No aparece

## Dirección
📍 Envíame tu dirección completa + referencia.

## Confirmación final
🧾 *Resumen*
{LISTA_ITEMS}
Subtotal: S/{SUBTOTAL}
Delivery: S/{DELIVERY}
Total: S/{TOTAL}

¿Confirmas? ✅ *SI* / ❌ *NO*

## Pedido confirmado
✅ Pedido confirmado 🎉
📌 N°: {ID}
