from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class Order(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    restaurant_id: int = Field(index=True)
    customer_name: str = ""
    customer_phone: str = Field(index=True, default="")
    delivery_type: str = "delivery"  # delivery | pickup
    address: str = ""
    address_lat: Optional[float] = None
    address_lng: Optional[float] = None
    zone_label: str = ""
    delivery_fee: float = 0.0
    resolved_address: str = ""
    status: str = "pending"  # pending | kitchen | sent | done | cancelled
    total: float = 0.0
    created_at: datetime = Field(default_factory=datetime.utcnow)

class OrderItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    order_id: int = Field(index=True)
    name: str
    qty: int = 1
    unit_price: float = 0.0
    line_total: float = 0.0
