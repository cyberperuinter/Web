from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class Restaurant(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    owner_user_id: int = Field(index=True)
    name: str
    phone: str = ""
    address: str = ""
    base_lat: Optional[float] = None
    base_lng: Optional[float] = None
    delivery_rules_json: str = ""  # JSON list of tiers: [{max_km, fee, label}]
    created_at: datetime = Field(default_factory=datetime.utcnow)
