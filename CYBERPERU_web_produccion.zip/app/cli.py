import typer
import logging
from sqlmodel import Session, select
from app.db import engine, create_db_and_tables
from app.models.user import User
from app.models.restaurant import Restaurant
from app.models.menu import MenuItem
from app.security import hash_password

app = typer.Typer()

logger = logging.getLogger("restoauto.cli")

@app.command("init-db")
def init_db():
    create_db_and_tables()
    logger.info("DB creada/verificada")

@app.command("seed-demo")
def seed_demo():
    create_db_and_tables()
    with Session(engine) as session:
        # Admin demo
        if not session.exec(select(User).where(User.email == "admin@demo.com")).first():
            u = User(email="admin@demo.com", hashed_password=hash_password("Admin123!"), role="admin")
            session.add(u)
            session.commit()
            session.refresh(u)
            r = Restaurant(owner_user_id=u.id, name="Pollería Demo", phone="+51999999999", address="Av. Demo 123, Lima")
            session.add(r)
            session.commit()
            session.refresh(r)

            items = [
                MenuItem(restaurant_id=r.id, category="Pollos", name="1 Pollo a la brasa", price=48.0),
                MenuItem(restaurant_id=r.id, category="Pollos", name="1/2 Pollo a la brasa", price=28.0),
                MenuItem(restaurant_id=r.id, category="Bebidas", name="Gaseosa 1.5L", price=10.0),
            ]
            for it in items:
                session.add(it)
            session.commit()
            logger.info("Datos demo cargados")
        else:
            logger.info("Demo ya existe")

if __name__ == "__main__":
    app()
