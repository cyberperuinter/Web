from datetime import datetime, timedelta, timezone
from typing import Optional
from sqlmodel import Session, select
from app.models.billing import Subscription, Payment


# ============================================
# PLANES
# ============================================

PLANS = {
    "basic": {"name": "Básico", "price": 39.0},
    "pro": {"name": "Pro", "price": 69.0},
    "elite": {"name": "Elite", "price": 99.0},
}

PERIOD_DAYS = 30


# ============================================
# HELPERS
# ============================================

def _now() -> datetime:
    """Fecha actual en UTC con timezone."""
    return datetime.now(timezone.utc)


# ============================================
# SUBSCRIPTION
# ============================================

def ensure_subscription(session: Session, restaurant_id: int) -> Subscription:
    sub = session.exec(
        select(Subscription).where(Subscription.restaurant_id == restaurant_id)
    ).first()

    if not sub:
        sub = Subscription(
            restaurant_id=restaurant_id,
            plan="basic",
            status="inactive",
            current_period_end=_now(),
        )
        session.add(sub)
        session.commit()
        session.refresh(sub)

    return sub


def is_active(sub: Subscription) -> bool:
    return sub.status == "active" and sub.current_period_end > _now()


def activate_subscription(session: Session, restaurant_id: int, plan: str) -> Subscription:
    sub = ensure_subscription(session, restaurant_id)

    sub.plan = plan
    sub.status = "active"

    # Si todavía está activo, extiende desde el final actual
    start = sub.current_period_end if sub.current_period_end > _now() else _now()
    sub.current_period_end = start + timedelta(days=PERIOD_DAYS)

    session.add(sub)
    session.commit()
    session.refresh(sub)

    return sub


# ============================================
# PAYMENTS
# ============================================

def create_payment(
    session: Session,
    restaurant_id: int,
    provider: str,
    plan: str,
    reference: str = "",
    proof_path: str = "",
) -> Payment:

    info = PLANS.get(plan) or PLANS["basic"]

    pay = Payment(
        restaurant_id=restaurant_id,
        provider=provider,
        amount=float(info["price"]),
        currency="PEN",
        status="pending",
        reference=reference,
        proof_path=proof_path,
        created_at=_now(),   # 🔥 ahora guardamos fecha creación
    )

    session.add(pay)
    session.commit()
    session.refresh(pay)

    return pay


def mark_payment_captured(
    session: Session,
    payment: Payment,
    paid_time_iso: Optional[str] = None,
) -> Payment:
    """
    Marca un pago como capturado y guarda hora real del pago.
    """

    payment.status = "captured"

    if paid_time_iso:
        try:
            if paid_time_iso.endswith("Z"):
                paid_time_iso = paid_time_iso.replace("Z", "+00:00")
            payment.paid_at = datetime.fromisoformat(paid_time_iso)
        except Exception:
            payment.paid_at = _now()
    else:
        payment.paid_at = _now()

    session.add(payment)
    session.commit()
    session.refresh(payment)

    return payment
