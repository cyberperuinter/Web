from __future__ import annotations

from typing import Dict, Optional, Literal
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import Field


class Settings(BaseSettings):
    """
    Configuración CENTRAL de RestoAuto Pro (Producción/Dev)

    ✅ Carga variables desde entorno y desde .env
    ✅ No deja secretos hardcodeados (usa .env)
    ✅ Compatible con PayPal, Izipay y WhatsApp (Meta)
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # ==============================
    # APP
    # ==============================
    app_name: str = Field(default="RestoAuto Pro", alias="APP_NAME")
    base_url: str = Field(default="http://127.0.0.1:8000", alias="BASE_URL")
    secret_key: str = Field(default="CHANGE_ME", alias="SECRET_KEY")
    webhook_shared_token: str = Field(default="CHANGE_ME", alias="WEBHOOK_SHARED_TOKEN")

    # ==============================
    # EMPRESA / BRANDING
    # ==============================
    brand_name: str = Field(default="CYBER PERÚ", alias="BRAND_NAME")
    company_legal_name: str = Field(default="CYBER PERÚ", alias="COMPANY_LEGAL_NAME")
    company_city: str = Field(default="Lima, Perú", alias="COMPANY_CITY")
    company_address: str = Field(default="(Completar dirección)", alias="COMPANY_ADDRESS")
    company_founded_year: int = Field(default=2026, alias="COMPANY_FOUNDED_YEAR")
    company_ruc: str = Field(default="(Completar RUC)", alias="COMPANY_RUC")
    company_registration_note: str = Field(default="(Completar info legal)", alias="COMPANY_REGISTRATION_NOTE")

    # ==============================
    # CONTACTO
    # ==============================
    contact_whatsapp: str = Field(default="+51", alias="CONTACT_WHATSAPP")
    contact_email: str = Field(default="ventas@cyberperu.online", alias="CONTACT_EMAIL")
    contact_hours: str = Field(default="Lun–Sáb 9:00–20:00", alias="CONTACT_HOURS")
    contact_sales_note: str = Field(default="Atendemos a restaurantes y pollerías.", alias="CONTACT_SALES_NOTE")

    # ==============================
    # REDES SOCIALES (CYBERPERU Systems)
    # ==============================
    # Usa URLs completas (https://...)
    social_tiktok: str = Field(default="", alias="SOCIAL_TIKTOK")
    social_facebook: str = Field(default="", alias="SOCIAL_FACEBOOK")
    social_instagram: str = Field(default="", alias="SOCIAL_INSTAGRAM")
    social_youtube: str = Field(default="", alias="SOCIAL_YOUTUBE")

    # ==============================
    # SEGURIDAD / COOKIES
    # ==============================
    # En VPS con HTTPS (Nginx + cert), esto debe estar en true.
    cookie_secure: bool = Field(default=False, alias="COOKIE_SECURE")

    # ==============================
    # DATABASE
    # ==============================
    database_url: str = Field(default="sqlite:///./data/restoautos.db", alias="DATABASE_URL")

    # ==============================
    # WHATSAPP (META CLOUD API)
    # ==============================
    whatsapp_provider: str = Field(default="meta", alias="WHATSAPP_PROVIDER")
    meta_phone_number_id: Optional[str] = Field(default=None, alias="META_PHONE_NUMBER_ID")
    meta_access_token: Optional[str] = Field(default=None, alias="META_ACCESS_TOKEN")
    meta_verify_token: str = Field(default="CHANGE_ME", alias="META_VERIFY_TOKEN")
    meta_app_secret: Optional[str] = Field(default=None, alias="META_APP_SECRET")
    meta_graph_version: str = Field(default="v22.0", alias="META_GRAPH_VERSION")

    # Multi-restaurante mapping
    # Formato: "900533413153177:1,1234567890:2"
    phone_number_id_to_restaurant: str = Field(default="", alias="PHONE_NUMBER_ID_TO_RESTAURANT")

    # ==============================
    # PAYPAL
    # ==============================
    paypal_mode: Literal["sandbox", "live"] = Field(default="sandbox", alias="PAYPAL_MODE")
    paypal_client_id: Optional[str] = Field(default=None, alias="PAYPAL_CLIENT_ID")
    paypal_client_secret: Optional[str] = Field(default=None, alias="PAYPAL_CLIENT_SECRET")

    # ==============================
    # IZIPAY (LYRA/IZIPAY)
    # ==============================
    # Este campo NO lo tenías y por eso te salía:
    # AttributeError: 'Settings' object has no attribute 'izipay_env'
    izipay_env: Literal["test", "prod"] = Field(default="test", alias="IZIPAY_ENV")

    izipay_username: Optional[str] = Field(default=None, alias="IZIPAY_USERNAME")
    izipay_password: Optional[str] = Field(default=None, alias="IZIPAY_PASSWORD")
    izipay_public_key: Optional[str] = Field(default=None, alias="IZIPAY_PUBLIC_KEY")

    # Endpoints (se usan en app/izipay.py)
    # Si tu izipay.py llama settings.izipay_endpoint_test / prod, aquí ya existen.
    izipay_endpoint_test: str = Field(
        default="https://api.micuentaweb.pe/api-payment/V4/Charge/CreatePayment",
        alias="IZIPAY_ENDPOINT_TEST",
    )
    izipay_endpoint_prod: str = Field(
        default="https://api.micuentaweb.pe/api-payment/V4/Charge/CreatePayment",
        alias="IZIPAY_ENDPOINT_PROD",
    )

    # ==============================
    # HELPERS
    # ==============================
    def phone_number_map(self) -> Dict[str, int]:
        m: Dict[str, int] = {}
        raw = (self.phone_number_id_to_restaurant or "").strip()
        if not raw:
            return m

        for part in raw.split(","):
            part = part.strip()
            if not part or ":" not in part:
                continue

            k, v = part.split(":", 1)
            k = k.strip()
            v = v.strip()
            if not k or not v:
                continue

            try:
                m[k] = int(v)
            except Exception:
                continue

        return m


settings = Settings()
