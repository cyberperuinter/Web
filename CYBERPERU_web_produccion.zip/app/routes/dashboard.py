from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import RedirectResponse
from sqlmodel import Session, select
from app.db import get_session
from app.routes.deps import get_current_user, get_current_restaurant
from app.models.menu import MenuItem
from app.models.order import Order, OrderItem

router = APIRouter()

@router.get("/dashboard")
def dashboard(request: Request, session: Session = Depends(get_session), user=Depends(get_current_user), rest=Depends(get_current_restaurant)):
    menu = session.exec(select(MenuItem).where(MenuItem.restaurant_id == rest.id).order_by(MenuItem.category, MenuItem.name)).all()
    orders = session.exec(select(Order).where(Order.restaurant_id == rest.id).order_by(Order.created_at.desc()).limit(30)).all()
    return request.app.state.templates.TemplateResponse("dashboard.html", {
        "request": request, "user": user, "rest": rest, "menu": menu, "orders": orders
    })

@router.post("/dashboard/menu/add")
def add_menu_item(
    request: Request,
    category: str = Form(...),
    name: str = Form(...),
    price: float = Form(...),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    item = MenuItem(restaurant_id=rest.id, category=category.strip(), name=name.strip(), price=float(price))
    session.add(item)
    session.commit()
    return RedirectResponse(url="/dashboard", status_code=302)

@router.post("/dashboard/orders/{order_id}/status")
def update_order_status(
    order_id: int,
    status: str = Form(...),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    order = session.exec(select(Order).where(Order.id == order_id, Order.restaurant_id == rest.id)).first()
    if order:
        order.status = status
        session.add(order)
        session.commit()
    return RedirectResponse(url="/dashboard", status_code=302)


@router.post("/dashboard/settings/delivery")
def update_delivery_settings(
    request: Request,
    base_lat: str = Form(""),
    base_lng: str = Form(""),
    rules_json: str = Form(""),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    # sanitize
    try:
        rest.base_lat = float(base_lat) if base_lat.strip() else None
    except Exception:
        rest.base_lat = None
    try:
        rest.base_lng = float(base_lng) if base_lng.strip() else None
    except Exception:
        rest.base_lng = None

    # validate rules json (optional)
    cleaned = ""
    if rules_json.strip():
        try:
            data = __import__("json").loads(rules_json)
            if isinstance(data, list):
                cleaned = __import__("json").dumps(data, ensure_ascii=False)
        except Exception:
            cleaned = ""
    rest.delivery_rules_json = cleaned
    session.add(rest)
    session.commit()
    return RedirectResponse(url="/dashboard", status_code=302)
