from fastapi import APIRouter, Depends, Request, Form, UploadFile, File, HTTPException
from fastapi.responses import RedirectResponse
from sqlmodel import Session, select
from pathlib import Path
import uuid

from app.db import get_session
from app.routes.deps import get_current_user, get_current_restaurant
from app.models.billing import Payment
from app.billing import PLANS, ensure_subscription, activate_subscription, create_payment
from app.settings import settings
from app import paypal as paypal_api
from app import izipay as izipay_api


router = APIRouter()

UPLOAD_DIR = Path("./data/uploads")
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

@router.get("/billing")
def billing_page(
    request: Request,
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    sub = ensure_subscription(session, rest.id)
    return request.app.state.templates.TemplateResponse("billing.html", {
        "request": request,
        "user": user,
        "rest": rest,
        "sub": sub,
        "plans": PLANS,
        "settings": settings,
    })

@router.post("/billing/yape")
async def billing_yape_submit(
    request: Request,
    plan: str = Form(...),
    voucher: UploadFile = File(...),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    if plan not in PLANS:
        raise HTTPException(status_code=400, detail="Plan inválido")
    ext = (voucher.filename or "").split(".")[-1].lower()
    if ext not in ("png", "jpg", "jpeg", "webp", "pdf"):
        raise HTTPException(status_code=400, detail="Formato no permitido")
    fname = f"{uuid.uuid4().hex}.{ext}"
    path = UPLOAD_DIR / fname
    content = await voucher.read()
    path.write_bytes(content)

    pay = create_payment(session, rest.id, "yape", plan, reference=f"YAPE-{uuid.uuid4().hex[:8]}", proof_path=str(path))
    return RedirectResponse(url="/billing?ok=yape", status_code=302)

@router.post("/billing/paypal/create-order")
def paypal_create_order(
    request: Request,
    plan: str = Form(...),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    if plan not in PLANS:
        raise HTTPException(status_code=400, detail="Plan inválido")
    amount = float(PLANS[plan]["price"])
    return_url = f"{settings.base_url}/billing/paypal/return?plan={plan}"
    cancel_url = f"{settings.base_url}/billing?cancel=1"
    order = paypal_api.create_order(amount, "PEN", return_url, cancel_url)
    order_id = order["id"]
    create_payment(session, rest.id, "paypal", plan, reference=order_id)
    # Find approve link
    approve = next((l["href"] for l in order.get("links", []) if l.get("rel") == "approve"), None)
    return {"order_id": order_id, "approve_url": approve}

@router.get("/billing/paypal/return")
def paypal_return(
    request: Request,
    plan: str,
    token: str | None = None,  # PayPal usually returns ?token=ORDER_ID
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    order_id = token or request.query_params.get("token")
    if not order_id:
        return RedirectResponse(url="/billing?paypal=missing", status_code=302)
    capture = paypal_api.capture_order(order_id)
    status = capture.get("status")
    # Mark payment as captured if completed
    pay = session.exec(select(Payment).where(Payment.reference == order_id, Payment.restaurant_id == rest.id)).first()
    if pay:
        pay.status = "captured" if status == "COMPLETED" else "pending"
        session.add(pay)
        session.commit()
    if status == "COMPLETED":
        activate_subscription(session, rest.id, plan)
        return RedirectResponse(url="/billing?ok=paypal", status_code=302)
    return RedirectResponse(url="/billing?paypal=not_completed", status_code=302)


@router.post("/billing/izipay/create-formtoken")
def izipay_create_formtoken(
    request: Request,
    plan: str = Form(...),
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    if plan not in PLANS:
        raise HTTPException(status_code=400, detail="Plan inválido")
    amount = float(PLANS[plan]["price"])
    order_code = f"IZI-{rest.id}-{uuid.uuid4().hex[:10]}"
    res = izipay_api.create_formtoken(amount=amount, currency="PEN", order_id=order_code, customer_email=getattr(user, "email", ""))
    # The API typically returns: { status: "SUCCESS", answer: { formToken: "...", ... } }
    if res.get("status") != "SUCCESS":
        return {"ok": False, "error": res}
    form_token = (res.get("answer") or {}).get("formToken")
    if not form_token:
        return {"ok": False, "error": res}
    # Create pending payment record in DB
    create_payment(session, rest.id, "izipay", plan, reference=order_code)
    return {"ok": True, "formToken": form_token, "publicKey": settings.izipay_public_key}

@router.get("/billing/izipay")
def izipay_checkout(
    request: Request,
    plan: str,
    session: Session = Depends(get_session),
    user=Depends(get_current_user),
    rest=Depends(get_current_restaurant),
):
    # Only renders a checkout container; JS will request formToken
    sub = ensure_subscription(session, rest.id)
    return request.app.state.templates.TemplateResponse("izipay_checkout.html", {
        "request": request,
        "user": user,
        "rest": rest,
        "plan": plan,
        "sub": sub,
        "plans": PLANS,
        "settings": settings
    })