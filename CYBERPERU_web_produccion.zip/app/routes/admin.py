from fastapi import APIRouter, Depends, Request, Form, HTTPException
from fastapi.responses import RedirectResponse
from sqlmodel import Session, select

from app.db import get_session
from app.routes.deps import get_current_user
from app.models.billing import Payment
from app.billing import activate_subscription, PLANS

router = APIRouter(prefix="/admin")

def _require_admin(user):
    if getattr(user, "role", "") != "admin":
        raise HTTPException(status_code=403, detail="Solo admin")

@router.get("/payments")
def admin_payments(request: Request, session: Session = Depends(get_session), user=Depends(get_current_user)):
    _require_admin(user)
    pays = session.exec(select(Payment).order_by(Payment.created_at.desc()).limit(200)).all()
    return request.app.state.templates.TemplateResponse("admin_payments.html", {"request": request, "user": user, "pays": pays, "plans": PLANS})

@router.post("/payments/{payment_id}/approve")
def approve(payment_id: int, plan: str = Form(...), session: Session = Depends(get_session), user=Depends(get_current_user)):
    _require_admin(user)
    pay = session.exec(select(Payment).where(Payment.id == payment_id)).first()
    if pay:
        pay.status = "approved"
        session.add(pay)
        session.commit()
        # Activate subscription
        activate_subscription(session, pay.restaurant_id, plan if plan in PLANS else "basic")
    return RedirectResponse(url="/admin/payments", status_code=302)

@router.post("/payments/{payment_id}/reject")
def reject(payment_id: int, session: Session = Depends(get_session), user=Depends(get_current_user)):
    _require_admin(user)
    pay = session.exec(select(Payment).where(Payment.id == payment_id)).first()
    if pay:
        pay.status = "rejected"
        session.add(pay)
        session.commit()
    return RedirectResponse(url="/admin/payments", status_code=302)
