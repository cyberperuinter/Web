from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, Any, List
import math
import re
import requests

_GOOGLE_COORD_RE = re.compile(r"@(-?\d+\.\d+),(-?\d+\.\d+)")
_Q_COORD_RE = re.compile(r"[?&]q=(-?\d+\.\d+),(-?\d+\.\d+)")
_LL_COORD_RE = re.compile(r"[?&]ll=(-?\d+\.\d+),(-?\d+\.\d+)")

def extract_coords(text: str) -> Optional[Tuple[float, float]]:
    """Try to extract lat/lng from a Google Maps link or '@lat,lng' pattern."""
    if not text:
        return None
    t = text.strip()
    for rx in (_GOOGLE_COORD_RE, _Q_COORD_RE, _LL_COORD_RE):
        m = rx.search(t)
        if m:
            return float(m.group(1)), float(m.group(2))
    return None

def haversine_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    R = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dl = math.radians(lon2 - lon1)
    a = math.sin(dphi/2)**2 + math.cos(p1)*math.cos(p2)*math.sin(dl/2)**2
    return 2*R*math.asin(math.sqrt(a))

def geocode_address_nominatim(address: str, timeout: int = 8) -> Optional[Tuple[float, float, str]]:
    """Geocode an address using OpenStreetMap Nominatim (free, rate-limited).
    Returns (lat, lon, display_name) or None.
    """
    if not address or len(address.strip()) < 5:
        return None
    url = "https://nominatim.openstreetmap.org/search"
    params = {"q": address, "format": "json", "limit": 1}
    headers = {"User-Agent": "CYBERPERU-RestoFlow/1.0 (support@cyberperu.local)"}
    try:
        r = requests.get(url, params=params, headers=headers, timeout=timeout)
        if r.status_code != 200:
            return None
        data = r.json() or []
        if not data:
            return None
        it = data[0]
        lat = float(it["lat"]); lon = float(it["lon"])
        name = str(it.get("display_name","")).strip()
        return lat, lon, name
    except Exception:
        return None

@dataclass
class DeliveryQuote:
    ok: bool
    fee: float = 0.0
    distance_km: float = 0.0
    zone_label: str = ""
    resolved_address: str = ""
    note: str = ""

def quote_delivery(
    *,
    rest_lat: Optional[float],
    rest_lng: Optional[float],
    user_lat: Optional[float],
    user_lng: Optional[float],
    address_text: str,
    rules: Optional[List[Dict[str, Any]]] = None,
    fallback_zones_keywords: Optional[Dict[str, Dict[str, Any]]] = None,
) -> DeliveryQuote:
    """Compute delivery fee using distance tiers if coords available; otherwise keyword fallback."""
    # 1) Distance-based
    if rest_lat is not None and rest_lng is not None and user_lat is not None and user_lng is not None:
        d = haversine_km(rest_lat, rest_lng, user_lat, user_lng)
        rules = rules or [
            {"max_km": 2.0, "fee": 5.0, "label": "Cerca"},
            {"max_km": 4.0, "fee": 6.0, "label": "Media"},
            {"max_km": 7.0, "fee": 7.0, "label": "Lejos"},
        ]
        # sort by max_km
        rules = sorted(rules, key=lambda x: float(x.get("max_km", 9999)))
        for r in rules:
            if d <= float(r.get("max_km", 9999)):
                return DeliveryQuote(
                    ok=True,
                    fee=float(r.get("fee", 0.0)),
                    distance_km=float(d),
                    zone_label=str(r.get("label", f"<= {r.get('max_km')}km")),
                )
        return DeliveryQuote(ok=True, fee=float(rules[-1].get("fee", 0.0)), distance_km=float(d), zone_label=str(rules[-1].get("label","Lejos")))
    # 2) Keyword-based fallback (Lurín presets)
    t = (address_text or "").lower()
    if fallback_zones_keywords:
        for label, cfg in fallback_zones_keywords.items():
            kws = [k.lower() for k in cfg.get("keywords", [])]
            if any(k in t for k in kws):
                return DeliveryQuote(ok=True, fee=float(cfg.get("fee", 0.0)), zone_label=label, note="detección por texto")
    return DeliveryQuote(ok=False, note="sin coordenadas ni coincidencias")
