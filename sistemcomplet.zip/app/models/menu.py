from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class MenuItem(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    restaurant_id: int = Field(index=True)
    category: str = Field(default="Pollos")
    name: str
    price: float = 0.0
    is_active: bool = True
    created_at: datetime = Field(default_factory=datetime.utcnow)
