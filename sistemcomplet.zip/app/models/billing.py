from typing import Optional
from datetime import datetime
from sqlmodel import SQLModel, Field

class Subscription(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    restaurant_id: int = Field(index=True)
    plan: str = "basic"  # basic | pro | elite
    status: str = "inactive"  # inactive | active | past_due
    current_period_end: datetime = Field(default_factory=datetime.utcnow)

class Payment(SQLModel, table=True):
    id: Optional[int] = Field(default=None, primary_key=True)
    restaurant_id: int = Field(index=True)
    provider: str  # yape | paypal
    amount: float
    currency: str = "PEN"
    status: str = "pending"  # pending | approved | rejected | captured
    reference: str = ""      # paypal order id / internal code
    proof_path: str = ""     # for yape voucher image path
    created_at: datetime = Field(default_factory=datetime.utcnow)
