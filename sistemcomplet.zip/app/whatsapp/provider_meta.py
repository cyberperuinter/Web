import requests
from app.settings import settings


def send_text(to_phone: str, text: str) -> None:
    """
    Envía un mensaje de texto por WhatsApp Cloud API (Meta).

    Requiere:
      - META_ACCESS_TOKEN
      - META_PHONE_NUMBER_ID

    Nota:
      - En modo DEV de Meta, solo podrás enviar a números en la *allowed list*.
      - En producción, esto se habilita según el estado de tu WABA / número.
    """
    if not settings.meta_access_token or not settings.meta_phone_number_id:
        raise RuntimeError("Falta META_ACCESS_TOKEN o META_PHONE_NUMBER_ID en configuración.")

    url = f"https://graph.facebook.com/{settings.meta_graph_version}/{settings.meta_phone_number_id}/messages"
    headers = {
        "Authorization": f"Bearer {settings.meta_access_token}",
        "Content-Type": "application/json",
    }
    payload = {
        "messaging_product": "whatsapp",
        "to": to_phone,
        "type": "text",
        "text": {"body": text},
    }

    r = requests.post(url, headers=headers, json=payload, timeout=15)

    if r.status_code >= 400:
        raise RuntimeError(f"Meta API error {r.status_code}: {r.text}")
