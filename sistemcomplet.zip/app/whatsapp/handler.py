"""WhatsApp message handler (state machine) — CYBER PERÚ.
- Soporta dirección por texto, link Google Maps o payload location {lat,lng}
- Calcula zona y delivery automáticamente (por distancia si hay base_lat/base_lng)
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Any
from sqlmodel import Session, select
from app.models.restaurant import Restaurant
from app.models.menu import MenuItem
from app.models.order import Order, OrderItem
from app.geo import extract_coords, geocode_address_nominatim, quote_delivery

@dataclass
class CartItem:
    name: str
    qty: int
    unit_price: float

@dataclass
class ChatState:
    step: str = "start"  # start | choosing | cart | delivery_mode | address | confirm
    cart: List[CartItem] = field(default_factory=list)
    delivery_type: str = "delivery"
    address: str = ""
    address_lat: Optional[float] = None
    address_lng: Optional[float] = None
    resolved_address: str = ""
    zone_label: str = ""
    delivery_fee: float = 0.0
    distance_km: float = 0.0

STATE: Dict[str, ChatState] = {}

def _menu_text(session: Session, rest: Restaurant) -> str:
    items = session.exec(select(MenuItem).where(MenuItem.restaurant_id == rest.id, MenuItem.is_active == True)).all()
    if not items:
        return "📋 Aún no hay menú cargado."
    lines = ["📋 *MENÚ*"]
    for i, it in enumerate(items, start=1):
        lines.append(f"{i}. {it.name} - S/{it.price:.2f}")
    lines.append("\nResponde con el número para agregar.\nEscribe *confirmar* para continuar.\nEscribe *cancelar* para salir.")
    return "\n".join(lines)

def _fallback_keywords():
    # Presets Lurín: ayudan si el cliente solo escribe texto sin GPS
    return {
        "Lurín Centro": {"fee": 5.0, "keywords": ["lurin centro", "plaza", "mercado", "av san pedro", "ramon castilla", "av lima"]},
        "Julio C. Tello": {"fee": 6.0, "keywords": ["julio", "tello", "aa.hh", "asentamiento", "las flores"]},
        "Mamacona / Las Flores": {"fee": 7.0, "keywords": ["mamacona", "caseta mamacona", "las flores", "pachacamac", "cruce pachacamac"]},
        "Puente San Luis / Boza": {"fee": 7.0, "keywords": ["puente san luis", "san luis", "boza", "bozo", "caseta boza", "caseta bozo"]},
    }

def handle_incoming(session: Session, rest: Restaurant, from_phone: str, text: str, payload: Optional[dict] = None) -> str:
    raw = (text or "").strip()
    t = raw.lower()

    st = STATE.get(from_phone) or ChatState()
    STATE[from_phone] = st

    # Allow reset
    if t in ("cancelar", "salir", "0"):
        STATE[from_phone] = ChatState()
        return "✅ Listo. Escribe *hola* para empezar de nuevo."

    if st.step == "start":
        st.step = "choosing"
        return (
            f"👋 Bienvenido a *{rest.name}*\n"
            "1️⃣ Ver menú\n"
            "2️⃣ Promos\n"
            "3️⃣ Hacer pedido\n"
            "4️⃣ Horarios y ubicación\n\n"
            "Responde con 1, 2, 3 o 4"
        )

    if st.step == "choosing":
        if t in ("1", "3") or "menu" in t or "menú" in t:
            st.step = "cart"
            return _menu_text(session, rest)
        if t == "2":
            return "🔥 Promos del día: consulta en tienda o pide el menú con 1️⃣"
        if t == "4":
            msg = "📍 Ubicación: " + (rest.address or "(configurar en el panel)")
            msg += "\n🕒 Horario: 12:00 - 23:00 (editable)"
            return msg
        return "No te entendí 😅 Responde con 1, 2, 3 o 4."

    if st.step == "cart":
        if t == "confirmar" and st.cart:
            st.step = "delivery_mode"
            return "📦 ¿Es *delivery* o *recojo*? Responde: delivery / recojo"

        items = session.exec(select(MenuItem).where(MenuItem.restaurant_id == rest.id, MenuItem.is_active == True).order_by(MenuItem.id)).all()
        if t.isdigit():
            idx = int(t)
            if 1 <= idx <= len(items):
                it = items[idx-1]
                st.cart.append(CartItem(name=it.name, qty=1, unit_price=float(it.price)))
                subtotal = sum(ci.qty * ci.unit_price for ci in st.cart)
                return (
                    f"✅ Agregado: {it.name}\n"
                    f"🧾 Subtotal: S/{subtotal:.2f}\n\n"
                    "Escribe otro número para agregar más.\n"
                    "Escribe *confirmar* para continuar."
                )
        return "Responde con un número del menú, o escribe *confirmar*."

    if st.step == "delivery_mode":
        if "recojo" in t:
            st.delivery_type = "pickup"
            st.step = "confirm"
            return _confirm_text(st)
        if "delivery" in t:
            st.delivery_type = "delivery"
            st.step = "address"
            return (
                "📍 Envíame tu dirección *o* tu ubicación 📍 (pin) *o* un link de Google Maps.\n"
                "✅ Así llegamos sin fallas (avenidas/jirones/asentamientos)."
            )
        return "Responde: delivery o recojo."

    if st.step == "address":
        # Try location from payload first
        user_lat = user_lng = None
        if isinstance(payload, dict):
            loc = payload.get("location") or {}
            try:
                user_lat = float(loc.get("lat")) if loc.get("lat") is not None else None
                user_lng = float(loc.get("lng")) if loc.get("lng") is not None else None
            except Exception:
                user_lat = user_lng = None

        # Try extract from text (Google Maps link)
        if user_lat is None or user_lng is None:
            coords = extract_coords(raw)
            if coords:
                user_lat, user_lng = coords

        # Save address text (always keep what user wrote)
        st.address = raw

        # If no coords, try geocode text (works for any place, but rate-limited)
        resolved = ""
        if user_lat is None or user_lng is None and len(raw) >= 5:
            g = geocode_address_nominatim(raw)
            if g:
                user_lat, user_lng, resolved = g

        st.address_lat = user_lat
        st.address_lng = user_lng
        st.resolved_address = resolved

        # Delivery quote
        rules = None
        if getattr(rest, "delivery_rules_json", ""):
            try:
                import json
                rules = json.loads(rest.delivery_rules_json) if rest.delivery_rules_json else None
            except Exception:
                rules = None

        q = quote_delivery(
            rest_lat=getattr(rest, "base_lat", None),
            rest_lng=getattr(rest, "base_lng", None),
            user_lat=user_lat,
            user_lng=user_lng,
            address_text=raw,
            rules=rules,
            fallback_zones_keywords=_fallback_keywords(),
        )

        if q.ok:
            st.zone_label = q.zone_label
            st.delivery_fee = float(q.fee)
            st.distance_km = float(q.distance_km or 0.0)
            st.step = "confirm"
            return _confirm_text(st)
        else:
            # If we can't detect zone, ask for pin
            return (
                "Para evitar errores de dirección 🙏\n"
                "✅ Envíame tu ubicación 📍 (pin) o un link de Google Maps.\n"
                "Luego te confirmo el delivery automáticamente."
            )

    if st.step == "confirm":
        if t in ("si", "sí", "confirmo", "confirmar", "ok"):
            order_id = _create_order(session, rest, from_phone, st)
            STATE[from_phone] = ChatState()
            return f"✅ Pedido registrado. *N° {order_id}*\nTe contactaremos para confirmar."
        if t in ("no", "cancelar"):
            STATE[from_phone] = ChatState()
            return "❌ Pedido cancelado. Escribe *hola* para empezar de nuevo."
        return "Responde *SI* para confirmar o *NO* para cancelar."

    STATE[from_phone] = ChatState()
    return "Escribe *hola* para comenzar."

def _confirm_text(st: ChatState) -> str:
    lines = ["🧾 *Resumen del pedido*:"]

    subtotal = 0.0
    for ci in st.cart:
        line = ci.qty * ci.unit_price
        subtotal += line
        lines.append(f"- {ci.qty} x {ci.name} = S/{line:.2f}")

    total = subtotal
    if st.delivery_type == "delivery":
        # add delivery fee if available
        if st.delivery_fee > 0:
            total += st.delivery_fee
        zone = st.zone_label or "(por confirmar)"
        fee_txt = f"S/{st.delivery_fee:.2f}" if st.delivery_fee else "(por confirmar)"
        dist_txt = f" • {st.distance_km:.1f} km" if st.distance_km else ""
        lines.append("")
        lines.append(f"📍 Dirección: {st.address or '(pendiente)'}")
        if st.resolved_address:
            lines.append(f"🧭 Ubicación detectada: {st.resolved_address}")
        lines.append(f"🧾 Zona: *{zone}*{dist_txt}")
        lines.append(f"🚚 Delivery: *{fee_txt}*")
        lines.append(f"\nSubtotal: S/{subtotal:.2f}")
        lines.append(f"Total: *S/{total:.2f}*")
    else:
        lines.append("\n🏃 Modalidad: Recojo en tienda")
        lines.append(f"\nTotal: *S/{total:.2f}*")

    lines.append("\n¿Confirmas el pedido? Responde: SI / NO")
    return "\n".join(lines)

def _create_order(session: Session, rest: Restaurant, phone: str, st: ChatState) -> int:
    subtotal = sum(ci.qty * ci.unit_price for ci in st.cart)
    total = subtotal + (st.delivery_fee if st.delivery_type == "delivery" else 0.0)

    order = Order(
        restaurant_id=rest.id,
        customer_phone=phone,
        delivery_type=st.delivery_type,
        address=st.address if st.delivery_type == "delivery" else "",
        address_lat=st.address_lat,
        address_lng=st.address_lng,
        zone_label=st.zone_label,
        delivery_fee=float(st.delivery_fee or 0.0),
        resolved_address=st.resolved_address or "",
        status="pending",
        total=float(total),
    )
    session.add(order)
    session.commit()
    session.refresh(order)

    for ci in st.cart:
        oi = OrderItem(
            order_id=order.id,
            name=ci.name,
            qty=ci.qty,
            unit_price=ci.unit_price,
            line_total=ci.qty * ci.unit_price
        )
        session.add(oi)
    session.commit()
    return order.id
