import base64
import requests
from typing import Optional
from app.settings import settings


# =====================================================
# CONFIG BASE URL
# =====================================================

def _base_url() -> str:
    mode = (settings.paypal_mode or "sandbox").lower()
    if mode == "sandbox":
        return "https://api-m.sandbox.paypal.com"
    return "https://api-m.paypal.com"


# =====================================================
# AUTH HEADER
# =====================================================

def _auth_header() -> str:
    if not settings.paypal_client_id or not settings.paypal_client_secret:
        raise RuntimeError("PAYPAL_CLIENT_ID o PAYPAL_CLIENT_SECRET no configurados en .env")

    raw = f"{settings.paypal_client_id}:{settings.paypal_client_secret}".encode("utf-8")
    encoded = base64.b64encode(raw).decode("utf-8")
    return f"Basic {encoded}"


# =====================================================
# ACCESS TOKEN
# =====================================================

def get_access_token() -> str:
    url = _base_url() + "/v1/oauth2/token"

    headers = {
        "Authorization": _auth_header(),
        "Accept": "application/json",
        "Accept-Language": "en_US",
    }

    data = {"grant_type": "client_credentials"}

    r = requests.post(url, headers=headers, data=data, timeout=20)

    if not r.ok:
        raise RuntimeError(f"Error obteniendo token PayPal: {r.status_code} {r.text}")

    return r.json().get("access_token")


# =====================================================
# CREATE ORDER
# =====================================================

def create_order(amount: float, currency: str, return_url: str, cancel_url: str) -> dict:
    token = get_access_token()

    url = _base_url() + "/v2/checkout/orders"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    payload = {
        "intent": "CAPTURE",
        "purchase_units": [
            {
                "amount": {
                    "currency_code": currency,
                    "value": f"{amount:.2f}",
                }
            }
        ],
        "application_context": {
            "return_url": return_url,
            "cancel_url": cancel_url,
        },
    }

    r = requests.post(url, headers=headers, json=payload, timeout=20)

    if not r.ok:
        raise RuntimeError(f"Error creando orden PayPal: {r.status_code} {r.text}")

    return r.json()


# =====================================================
# CAPTURE ORDER
# =====================================================

def capture_order(order_id: str) -> dict:
    token = get_access_token()

    url = _base_url() + f"/v2/checkout/orders/{order_id}/capture"

    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
        "Accept": "application/json",
    }

    r = requests.post(url, headers=headers, json={}, timeout=20)

    if not r.ok:
        raise RuntimeError(f"Error capturando orden PayPal: {r.status_code} {r.text}")

    return r.json()


# =====================================================
# EXTRAER HORA REAL DEL PAGO
# =====================================================

def extract_paid_time(capture_data: dict) -> Optional[str]:
    """
    Devuelve la hora real del pago en formato ISO.
    Ejemplo: 2026-02-12T19:10:33Z
    """
    try:
        captures = (
            capture_data.get("purchase_units", [{}])[0]
            .get("payments", {})
            .get("captures", [])
        )

        if not captures:
            return None

        return captures[0].get("create_time")

    except Exception:
        return None
