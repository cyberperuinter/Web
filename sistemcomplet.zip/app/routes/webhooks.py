from __future__ import annotations

import hmac
import hashlib
from typing import Any, Dict, Optional, Tuple

from fastapi import APIRouter, Request, Depends, Header, HTTPException
from sqlmodel import Session, select

from app.db import get_session
from app.models.restaurant import Restaurant
from app.settings import settings
from app.whatsapp.handler import handle_incoming
from app.whatsapp.provider_meta import send_text

router = APIRouter(prefix="/webhooks")


def _verify_shared_token(x_webhook_token: Optional[str]) -> None:
    if settings.webhook_shared_token and settings.webhook_shared_token != "CHANGE_ME":
        if not x_webhook_token or x_webhook_token != settings.webhook_shared_token:
            raise HTTPException(status_code=401, detail="Invalid webhook token")


def _verify_meta_signature(request_body: bytes, x_hub_signature_256: Optional[str]) -> None:
    if not settings.verify_webhook_signature:
        return
    # si no hay signature, no validamos (no rompe modo simulación)
    if not x_hub_signature_256:
        return

    if not settings.meta_app_secret or settings.meta_app_secret == "CHANGE_ME":
        raise HTTPException(status_code=500, detail="META_APP_SECRET not configured")

    if not x_hub_signature_256.startswith("sha256="):
        raise HTTPException(status_code=401, detail="Invalid X-Hub-Signature-256")

    sig = x_hub_signature_256.split("=", 1)[1].strip()
    mac = hmac.new(
        settings.meta_app_secret.encode("utf-8"),
        msg=request_body,
        digestmod=hashlib.sha256,
    ).hexdigest()

    if not hmac.compare_digest(mac, sig):
        raise HTTPException(status_code=401, detail="Invalid signature")


def _extract_meta_message(data: Dict[str, Any]) -> Optional[Tuple[str, str, Dict[str, Any], int]]:
    try:
        entry = (data.get("entry") or [])[0]
        changes = (entry.get("changes") or [])[0]
        value = changes.get("value") or {}

        metadata = value.get("metadata") or {}
        phone_number_id = str(metadata.get("phone_number_id") or "").strip()

        rest_id = 1
        if hasattr(settings, "phone_number_map"):
            try:
                m = settings.phone_number_map()  # type: ignore[attr-defined]
                if phone_number_id and phone_number_id in m:
                    rest_id = int(m[phone_number_id])
            except Exception:
                rest_id = 1

        messages = value.get("messages") or []
        if not messages:
            return None

        msg = messages[0]
        from_phone = str(msg.get("from", "")).strip()

        text = ""
        extra: Dict[str, Any] = {"meta": {"phone_number_id": phone_number_id, "raw": data}}

        mtype = msg.get("type")
        if mtype == "text":
            text = (msg.get("text") or {}).get("body") or ""
        elif mtype == "interactive":
            inter = msg.get("interactive") or {}
            if "button_reply" in inter:
                br = inter.get("button_reply") or {}
                text = br.get("title") or br.get("id") or ""
            elif "list_reply" in inter:
                lr = inter.get("list_reply") or {}
                text = lr.get("title") or lr.get("id") or ""
        elif mtype == "location":
            loc = msg.get("location") or {}
            text = "ubicacion"
            extra["location"] = {"lat": loc.get("latitude"), "lng": loc.get("longitude")}
        else:
            text = ""

        return from_phone, str(text).strip(), extra, rest_id
    except Exception:
        return None


@router.get("/whatsapp")
async def whatsapp_verify(request: Request):
    qp = request.query_params
    mode = qp.get("hub.mode")
    token = qp.get("hub.verify_token")
    challenge = qp.get("hub.challenge")

    if mode == "subscribe" and token == settings.meta_verify_token:
        return challenge or ""

    raise HTTPException(status_code=403, detail="Verification failed")


@router.post("/whatsapp")
async def whatsapp_webhook(
    request: Request,
    session: Session = Depends(get_session),
    x_webhook_token: Optional[str] = Header(default=None, alias="X-Webhook-Token"),
    x_hub_signature_256: Optional[str] = Header(default=None, alias="X-Hub-Signature-256"),
):
    body = await request.body()

    _verify_shared_token(x_webhook_token)
    _verify_meta_signature(body, x_hub_signature_256)

    try:
        data = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON")

    from_phone = ""
    text = ""
    rest_id = 1
    extra_payload: Dict[str, Any] = {}

    parsed = _extract_meta_message(data) if isinstance(data, dict) else None
    if parsed:
        from_phone, text, extra_payload, rest_id = parsed
    else:
        if isinstance(data, dict):
            from_phone = str(data.get("from", "")).strip()
            text = str(data.get("text", "")).strip()
            rest_id = int(data.get("restaurant_id", 1))
            extra_payload = data
        else:
            return {"ok": True}

    if not from_phone:
        return {"ok": True}

    rest = session.exec(select(Restaurant).where(Restaurant.id == rest_id)).first()
    if not rest:
        return {"ok": False, "error": "restaurant not found"}

    reply = handle_incoming(session, rest, from_phone, text, extra_payload)

    send_error = None
    try:
        send_text(from_phone, reply)
    except Exception as e:
        send_error = str(e)

    return {"ok": True, "reply": reply, "send_error": send_error}
