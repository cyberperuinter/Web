from fastapi import APIRouter, Depends
from sqlmodel import Session, select
from app.db import get_session
from app.routes.deps import get_current_user, get_current_restaurant
from app.models.menu import MenuItem
from app.models.order import Order, OrderItem

router = APIRouter(prefix="/api")

@router.get("/menu")
def get_menu(session: Session = Depends(get_session), user=Depends(get_current_user), rest=Depends(get_current_restaurant)):
    items = session.exec(select(MenuItem).where(MenuItem.restaurant_id == rest.id, MenuItem.is_active == True)).all()
    return items

@router.get("/orders")
def get_orders(session: Session = Depends(get_session), user=Depends(get_current_user), rest=Depends(get_current_restaurant)):
    orders = session.exec(select(Order).where(Order.restaurant_id == rest.id).order_by(Order.created_at.desc()).limit(100)).all()
    return orders
