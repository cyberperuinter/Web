from fastapi import APIRouter, Depends, Request, Form
from fastapi.responses import RedirectResponse
import logging
from sqlmodel import Session, select

from app.db import get_session
from app.models.user import User
from app.security import hash_password, verify_password, create_access_token

router = APIRouter()

logger = logging.getLogger("restoauto.auth")


def _norm_email(email: str) -> str:
    return (email or "").strip().lower()


@router.get("/login")
def login_page(request: Request):
    return request.app.state.templates.TemplateResponse(
        "login.html",
        {"request": request, "error": None},
    )


@router.post("/login")
def login_action(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    session: Session = Depends(get_session),
):
    email = _norm_email(email)

    user = session.exec(select(User).where(User.email == email)).first()
    if not user or not verify_password(password, user.hashed_password):
        return request.app.state.templates.TemplateResponse(
            "login.html",
            {"request": request, "error": "Credenciales inválidas."},
            status_code=401,
        )

    token = create_access_token(str(user.id))
    response = RedirectResponse(url="/dashboard", status_code=302)

    response.set_cookie(
        "access_token",
        token,
        httponly=True,
        samesite="lax",
        secure=False,  # cambia a True cuando tengas HTTPS en VPS
        max_age=60 * 60 * 24,
    )
    return response


@router.get("/logout")
def logout():
    response = RedirectResponse(url="/", status_code=302)
    response.delete_cookie("access_token")
    return response


@router.get("/register")
def register_page(request: Request):
    return request.app.state.templates.TemplateResponse(
        "register.html",
        {"request": request, "error": None},
    )


@router.post("/register")
def register_action(
    request: Request,
    email: str = Form(...),
    password: str = Form(...),
    restaurant_name: str = Form(...),
    session: Session = Depends(get_session),
):
    email = _norm_email(email)
    restaurant_name = (restaurant_name or "").strip()
    password = password or ""

    # Validaciones básicas
    if not email or "@" not in email:
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": "Email inválido."},
            status_code=400,
        )

    if not restaurant_name:
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": "Nombre del negocio requerido."},
            status_code=400,
        )

    if len(password) < 8:
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": "La contraseña debe tener mínimo 8 caracteres."},
            status_code=400,
        )

    # Email ya existe
    exists = session.exec(select(User).where(User.email == email)).first()
    if exists:
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": "Ese email ya está registrado."},
            status_code=409,
        )

    # Hash password (maneja ValueError)
    try:
        hashed = hash_password(password)
    except ValueError as e:
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": str(e)},
            status_code=400,
        )

    # Crear usuario + restaurante en una sola transacción
    from app.models.restaurant import Restaurant

    try:
        user = User(email=email, hashed_password=hashed, role="owner")
        session.add(user)
        session.flush()  # obtiene user.id sin commit

        rest = Restaurant(owner_user_id=user.id, name=restaurant_name)
        session.add(rest)

        session.commit()
        session.refresh(user)

    except Exception:
        session.rollback()
        logger.exception("REGISTER DB ERROR")
        return request.app.state.templates.TemplateResponse(
            "register.html",
            {"request": request, "error": "No se pudo crear la cuenta. Verifica los datos e inténtalo de nuevo."},
            status_code=400,
        )

    # Login automático después de registrar
    token = create_access_token(str(user.id))
    response = RedirectResponse(url="/dashboard", status_code=302)
    response.set_cookie(
        "access_token",
        token,
        httponly=True,
        samesite="lax",
        secure=False,  # True en HTTPS
        max_age=60 * 60 * 24,
    )
    return response
