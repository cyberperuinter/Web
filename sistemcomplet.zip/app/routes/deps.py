from fastapi import Request, HTTPException, Depends
from sqlmodel import Session, select
from app.db import get_session
from app.security import decode_token
from app.models.user import User
from app.models.restaurant import Restaurant

def get_current_user(request: Request, session: Session = Depends(get_session)) -> User:
    token = request.cookies.get("access_token")
    if not token:
        raise HTTPException(status_code=401, detail="No autenticado")
    sub = decode_token(token)
    if not sub:
        raise HTTPException(status_code=401, detail="Token inválido")
    user = session.exec(select(User).where(User.id == int(sub))).first()
    if not user:
        raise HTTPException(status_code=401, detail="Usuario no existe")
    return user

def get_current_restaurant(user: User = Depends(get_current_user), session: Session = Depends(get_session)) -> Restaurant:
    rest = session.exec(select(Restaurant).where(Restaurant.owner_user_id == user.id)).first()
    if not rest:
        raise HTTPException(status_code=404, detail="Restaurante no encontrado")
    return rest
