from fastapi import APIRouter, Request
from datetime import datetime


router = APIRouter()


def _ctx(request: Request, title: str):
    return {
        "request": request,
        "year": datetime.utcnow().year,
        "title": title,
        "user": None,
    }


@router.get("/planes")
def planes(request: Request):
    return request.app.state.templates.TemplateResponse("planes.html", _ctx(request, "Planes"))


@router.get("/como-comprar")
def como_comprar(request: Request):
    return request.app.state.templates.TemplateResponse("como_comprar.html", _ctx(request, "Cómo comprar"))


@router.get("/quienes-somos")
def quienes_somos(request: Request):
    return request.app.state.templates.TemplateResponse("quienes_somos.html", _ctx(request, "Quiénes somos"))


@router.get("/contacto")
def contacto(request: Request):
    return request.app.state.templates.TemplateResponse("contacto.html", _ctx(request, "Contacto"))


@router.get("/terminos")
def terminos(request: Request):
    return request.app.state.templates.TemplateResponse("terminos.html", _ctx(request, "Términos y condiciones"))


@router.get("/privacidad")
def privacidad(request: Request):
    return request.app.state.templates.TemplateResponse("privacidad.html", _ctx(request, "Política de privacidad"))
