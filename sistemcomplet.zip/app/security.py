from datetime import datetime, timedelta
from passlib.context import CryptContext
from jose import jwt, JWTError
from app.settings import settings

# ✅ PBKDF2_SHA256: estable en Windows + Python 3.14 (sin backend bcrypt)
pwd_context = CryptContext(
    schemes=["pbkdf2_sha256"],
    deprecated="auto",
)

ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60 * 24  # 24h


def hash_password(password: str) -> str:
    if password is None or not str(password).strip():
        raise ValueError("Contraseña inválida.")
    return pwd_context.hash(str(password))


def verify_password(password: str, hashed: str) -> bool:
    try:
        return pwd_context.verify(str(password or ""), hashed)
    except Exception:
        return False


def create_access_token(subject: str) -> str:
    expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    to_encode = {"sub": subject, "exp": expire}
    return jwt.encode(to_encode, settings.secret_key, algorithm=ALGORITHM)


def decode_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None
    except Exception:
        return None