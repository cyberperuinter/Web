import base64
import requests
from app.settings import settings

def _endpoint() -> str:
    return settings.izipay_endpoint_prod if settings.izipay_env == "prod" else settings.izipay_endpoint_test

def create_formtoken(amount: float, currency: str, order_id: str, customer_email: str = "") -> dict:
    """Genera formToken usando Charge/CreatePayment (micuentaweb / Lyra).
    Docs: https://api.micuentaweb.pe/api-payment/V4/Charge/CreatePayment
    """
    auth_raw = f"{settings.izipay_username}:{settings.izipay_password}".encode("utf-8")
    auth = base64.b64encode(auth_raw).decode("utf-8")

    payload = {
        "amount": int(round(amount * 100)),   # centimos
        "currency": currency,
        "orderId": order_id,
        "customer": {"email": customer_email} if customer_email else {},
    }

    headers = {
        "Authorization": f"Basic {auth}",
        "Content-Type": "application/json"
    }
    r = requests.post(_endpoint(), headers=headers, json=payload, timeout=25)
    r.raise_for_status()
    return r.json()
