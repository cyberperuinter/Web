from sqlmodel import SQLModel, create_engine, Session
from app.settings import settings
import pathlib


def get_engine():
    # Ensure ./data exists for sqlite file
    if settings.database_url.startswith("sqlite:///./"):
        db_path = settings.database_url.replace("sqlite:///./", "./")
        pathlib.Path(db_path).parent.mkdir(parents=True, exist_ok=True)

    connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
    return create_engine(settings.database_url, echo=False, connect_args=connect_args)


engine = get_engine()


def create_db_and_tables():
    SQLModel.metadata.create_all(engine)
    _sqlite_migrate()


def get_session():
    with Session(engine) as session:
        yield session


def _qident(name: str) -> str:
    """
    Quote seguro para identificadores SQLite (tablas/columnas).
    Maneja palabras reservadas como: order, group, user, etc.
    """
    if name is None:
        raise ValueError("Identifier name is None")
    return '"' + str(name).replace('"', '""') + '"'


def _sqlite_has_column(conn, table: str, column: str) -> bool:
    table_q = _qident(table)
    cur = conn.execute(f"PRAGMA table_info({table_q});")
    cols = [row[1] for row in cur.fetchall()]  # row[1] = column name
    return column in cols


def _sqlite_migrate():
    # Minimal safe migration for sqlite only: add missing columns.
    if not settings.database_url.startswith("sqlite"):
        return

    import sqlite3

    db_path = settings.database_url.replace("sqlite:///./", "./")
    conn = sqlite3.connect(db_path)

    try:
        # Restaurant
        for table, col, typ in [
            ("restaurant", "base_lat", "REAL"),
            ("restaurant", "base_lng", "REAL"),
            ("restaurant", "delivery_rules_json", "TEXT"),
        ]:
            if not _sqlite_has_column(conn, table, col):
                conn.execute(
                    f"ALTER TABLE {_qident(table)} ADD COLUMN {_qident(col)} {typ};"
                )

        # Order (⚠️ 'order' es palabra reservada)
        for table, col, typ in [
            ("order", "address_lat", "REAL"),
            ("order", "address_lng", "REAL"),
            ("order", "zone_label", "TEXT"),
            ("order", "delivery_fee", "REAL"),
            ("order", "resolved_address", "TEXT"),
        ]:
            if not _sqlite_has_column(conn, table, col):
                conn.execute(
                    f"ALTER TABLE {_qident(table)} ADD COLUMN {_qident(col)} {typ};"
                )

        conn.commit()
    finally:
        conn.close()
