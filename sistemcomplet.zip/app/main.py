from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from contextlib import asynccontextmanager
from datetime import datetime
import logging

from app.settings import settings
from app.db import create_db_and_tables
from app.routes.auth import router as auth_router
from app.routes.dashboard import router as dashboard_router
from app.routes.api import router as api_router
from app.routes.webhooks import router as webhooks_router
from app.routes.billing import router as billing_router
from app.routes.admin import router as admin_router
from app.routes.pages import router as pages_router

logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger("restoauto")


@asynccontextmanager
async def lifespan(app: FastAPI):
    # ✅ STARTUP
    create_db_and_tables()
    logger.info("DB ready. App started.")

    yield

    # ✅ SHUTDOWN (si luego quieres cerrar conexiones, va aquí)
    logger.info("App shutdown.")


app = FastAPI(title=settings.app_name, lifespan=lifespan)

templates = Jinja2Templates(directory="app/templates")
app.state.templates = templates

# Disponibles en todas las plantillas
templates.env.globals["settings"] = settings

templates.env.globals["now"] = __import__("datetime").datetime.utcnow

app.mount("/static", StaticFiles(directory="app/static"), name="static")

app.include_router(auth_router)
app.include_router(dashboard_router)
app.include_router(api_router)
app.include_router(webhooks_router)
app.include_router(billing_router)
app.include_router(admin_router)
app.include_router(pages_router)


@app.get("/")
def landing(request: Request):
    return templates.TemplateResponse(
        "index.html",
        {"request": request, "year": datetime.utcnow().year, "user": None},
    )


@app.get("/health")
def health():
    return {"ok": True}
