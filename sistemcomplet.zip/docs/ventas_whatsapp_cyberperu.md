# Mensajes estratégicos para cerrar ventas (WhatsApp) — CYBER PERÚ

## 1) Primer contacto (corto y directo)
Hola 👋 soy de *CYBER PERÚ* ⚡  
Ayudamos a pollerías y restaurantes de *Lurín* a **responder WhatsApp automáticamente** y **ordenar pedidos** para no perder ventas.

¿Te muestro una demo rápida (1 minuto)?

---

## 2) Después de la demo (enfocado en resultado)
Como viste:
✅ Atiende 24/7  
✅ Toma pedidos sin errores  
✅ Te llega todo al panel (cocina/delivery)

Lo activamos **hoy mismo**.
Costo: *S/69 mensual*.

¿Lo ponemos a correr?

---

## 3) Objeción “lo pienso” (cierre elegante)
Normal 👍  
Solo para que tengas referencia: con **1 o 2 pedidos** ya recuperas el costo del mes.

¿Te lo dejo activo hoy y lo pruebas con tus clientes?

---

## 4) Objeción “ya tengo WhatsApp normal”
Perfecto, esto *usa tu WhatsApp* pero lo convierte en sistema:
- menú automático
- zonas de delivery con precio
- confirmación SI/NO
- panel para ver pedidos

¿Quieres que lo veas funcionando con tu menú?

---

## 5) Cierre final (sin contrato)
No hay contrato ni permanencia.
Si no te sirve, lo cancelas.
Pero normalmente el negocio **vende más** porque responde rápido.

¿Te registro hoy?

---

## Oferta recomendada (Lurín)
- PRO: S/69 / mes (más vendible)
- ELITE: S/99 / mes (frecuentes + pedido rápido)
