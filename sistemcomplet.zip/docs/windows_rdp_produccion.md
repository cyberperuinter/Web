# Ponerlo a correr en Windows (RDP) – rápido y seguro

## A) Arranque inmediato (demo/local)
1) Descomprime en: C:\apps\restoflow\
2) Doble click: run_windows.bat
3) Abre: http://127.0.0.1:8000

## B) Para producción (recomendado)
- Deja la app en 127.0.0.1:8000
- Usa un reverse proxy con HTTPS (Caddy) en 80/443
- Corre como servicio con NSSM

(Esto ya está preparado para que lo completes cuando tengas dominio.)
