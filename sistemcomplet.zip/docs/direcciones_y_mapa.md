# Direcciones y “Mapa completo” — lo realista y lo que recomendamos

## Por qué NO se puede “incluir todas las direcciones de Lima” dentro del ZIP
- Un “mapa completo” (calles, jirones, avenidas, sectores) es una base de datos enorme (GBs)
- Requiere licencias y actualizaciones constantes
- No es práctico ni estable para un ZIP de lanzamiento

## Solución PRO que evita problemas de dirección (recomendada)
1) Pedir **pin de ubicación** (WhatsApp location) o **link de Google Maps**
2) Guardar “referencia” (Ej: “frente a la caseta”, “cerca al mercado”)
3) (Opcional) Autocompletar con geocoding online (cuando tengas dominio/VPS estable)

## Atajo rápido para Lurín (ya incluido)
- Presets de zonas y referencias en:
  - data/address_presets_lurin.json
  - data/lurin_zones.json

## Mensaje perfecto para el bot (cero fallas)
“✅ Para llegar sin problemas, envíame tu **ubicación (📍pin)** o un **link de Google Maps**. Si no puedes, escribe tu dirección + referencia.”
