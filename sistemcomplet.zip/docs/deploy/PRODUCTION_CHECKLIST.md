# Producción real - Checklist

## 1) Dominio + HTTPS
- Apunta tu dominio a tu VPS (A record)
- Instala Nginx
- Certbot (Let's Encrypt) para HTTPS

## 2) Variables .env
- Copia docs/deploy/.env.example -> /opt/cyberperu-vps/.env
- Cambia SECRET_KEY
- Configura DATABASE_URL (PostgreSQL recomendado)
- Configura META_* (token, phone_number_id, verify_token, app_secret)

## 3) Webhook Meta
- Callback URL: https://api.tudominio.com/webhooks/whatsapp
- Verify token: META_VERIFY_TOKEN
- Suscribe eventos: messages
- (Recomendado) Activa firma y valida con META_APP_SECRET

## 4) Servicio
- Crear venv en /opt/cyberperu-vps/.venv
- systemd: docs/deploy/restoauto.service
- systemctl enable --now restoauto

## 5) Hacerlo "real"
- Pasar número/WhatsApp Business a producción
- Quitar limitación de "allowed list" (modo dev)
