# Deploy en VPS (Ubuntu 22.04) — CYBER PERÚ (sin dominio)

## 0) Requisitos
- VPS Ubuntu 22.04 (1 vCPU / 2 GB RAM recomendado)
- Acceso SSH
- Puerto 8000 abierto (temporal) o 80/443 si usas proxy

## 1) Subir proyecto al VPS
En tu PC:
- Sube el zip por SFTP o WinSCP
- Descomprime en: /opt/cyberperu/

Ejemplo:
/opt/cyberperu/resto_saas_pro_yape_paypal_izipay/

## 2) Instalar dependencias
```bash
sudo apt update
sudo apt install -y python3 python3-venv python3-pip unzip
cd /opt/cyberperu/resto_saas_pro_yape_paypal_izipay
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

## 3) Correr (modo simple)
```bash
source venv/bin/activate
uvicorn app.main:app --host 0.0.0.0 --port 8000
```
Abre en:
- http://IP_DEL_VPS:8000

## 4) Producción con systemd (recomendado)
Crea servicio:
```bash
sudo nano /etc/systemd/system/cyberperu.service
```

Pega:
```ini
[Unit]
Description=CYBER PERU - Restaurant SaaS
After=network.target

[Service]
User=root
WorkingDirectory=/opt/cyberperu/resto_saas_pro_yape_paypal_izipay
ExecStart=/opt/cyberperu/resto_saas_pro_yape_paypal_izipay/venv/bin/uvicorn app.main:app --host 127.0.0.1 --port 8000
Restart=always

[Install]
WantedBy=multi-user.target
```

Activa:
```bash
sudo systemctl daemon-reload
sudo systemctl enable cyberperu
sudo systemctl start cyberperu
sudo systemctl status cyberperu
```

## 5) HTTPS (cuando compres dominio)
Recomendado: Caddy o Nginx reverse proxy.
Mientras no tengas dominio, puedes trabajar con IP:8000.
