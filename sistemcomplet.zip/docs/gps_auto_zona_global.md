# GPS + Auto-Zona (cualquier lugar) — cómo funciona

## Lo más seguro para NO fallar con direcciones
✅ Pide al cliente: ubicación 📍 (pin) o link de Google Maps.
- Con eso obtienes lat/lng exacto.

## Detección automática de zona
El sistema hace 2 cosas:
1) Si hay lat/lng:
   - Calcula distancia desde la ubicación base del negocio
   - Aplica reglas por km (tiers) y define delivery automáticamente

2) Si NO hay lat/lng:
   - Intenta geocodificar dirección con Nominatim (OpenStreetMap) (puede ser lento o fallar)
   - Si tampoco puede: pide pin/link

## Reglas por km (editable)
En Dashboard -> “Ubicación & Delivery” puedes poner reglas JSON:
[
  {"max_km":2,"fee":5,"label":"Cerca"},
  {"max_km":4,"fee":6,"label":"Media"},
  {"max_km":7,"fee":7,"label":"Lejos"}
]

Esto sirve en cualquier distrito/ciudad, no solo Lurín.
