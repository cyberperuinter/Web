# Flujo WhatsApp definitivo — CYBER PERÚ (Lurín)

## Entrada “hola / menu”
👋 ¡Hola! Bienvenido a *{NOMBRE_NEGOCIO}* 🍗🔥  
Atención automática con *CYBER PERÚ* ⚡

¿Qué deseas hacer?
1️⃣ Ver menú
2️⃣ Hacer pedido
3️⃣ Promos de hoy
4️⃣ Ubicación y horarios
5️⃣ Hablar con un asesor

---

## Menú (ejemplo)
📋 *MENÚ*
1️⃣ 1 Pollo a la brasa — S/48.00
2️⃣ 1/2 Pollo — S/28.00
3️⃣ 1/4 Pollo — S/16.00
4️⃣ Papas familiares — S/12.00
5️⃣ Ensalada — S/8.00
6️⃣ Gaseosa 1.5L — S/10.00

Responde con el número para agregar.
Escribe *CONFIRMAR* para continuar.
Escribe *CANCELAR* para salir.

---

## Delivery / Recojo
📦 ¿Cómo deseas tu pedido?
1️⃣ Delivery
2️⃣ Recojo en tienda

---

## Zonas (Lurín)
📍 ¿En qué zona te encuentras?
1️⃣ Lurín Centro (S/5)
2️⃣ Julio C. Tello (S/6)
3️⃣ Mamacona / Las Flores (S/7)
4️⃣ Puente San Luis / Boza (S/7)
5️⃣ No aparece

Si elige 5:
Lo sentimos 😕 por ahora no llegamos a esa zona.
¿Deseas recojo en tienda? Responde *SI* / *NO*

---

## Dirección (para evitar errores)
📍 Envíame tu dirección completa + referencia.
✅ Si puedes, envía tu **ubicación** (pin) o un **link de Google Maps** para llegar sin fallas.

Ejemplo:
Av. San Pedro 123, Lurín (cerca al Mercado)
o link/pin 📍

---

## Confirmación final
🧾 *Resumen*
{LISTA_ITEMS}
Subtotal: S/{SUBTOTAL}
Delivery: S/{DELIVERY}
Total: S/{TOTAL}

📍 Zona: {ZONA}
📍 Dirección: {DIRECCION}
⏱ {ETA_MIN}-{ETA_MAX} min aprox.

¿Confirmas?
✅ SI / ❌ NO

---

## Pedido confirmado
✅ Pedido confirmado 🎉
📌 N°: {ID}
Gracias por preferirnos 🙌
