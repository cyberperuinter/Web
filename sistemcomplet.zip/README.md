CYBER PERÚ ⚡ — Pedidos por WhatsApp (SaaS)

# RestoAuto Pro — Listo para Producción (VPS)

Plataforma web + backend para:
- Bot de WhatsApp (webhook) con menú y toma de pedidos
- Panel web (admin + negocio) para gestionar menú y pedidos
- Suscripciones / facturación (Yape / PayPal / Izipay)

## Requisitos
- Ubuntu 22.04/24.04 (recomendado)
- Python 3.11+ (probado 3.12)
- Nginx + HTTPS (Certbot o Cloudflare)

---

## Configuración (ENV)
1) Copia el ejemplo:
```bash
cp .env.example .env
```

2) Edita `.env` y define como mínimo:
- `BASE_URL=https://TU-DOMINIO`
- `SECRET_KEY=...` (obligatorio)
- `WEBHOOK_SHARED_TOKEN=...` (obligatorio)
- `DATABASE_URL=...` (SQLite o PostgreSQL)

> Importante: en producción NO subas `.env` al repositorio.

---

## Instalar (Linux/VPS)
```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m app.cli init-db
```

### (Opcional) Datos demo (solo desarrollo)
```bash
python -m app.cli seed-demo
```

---

## Ejecutar en Producción (Gunicorn)
Ejemplo manual:
```bash
source .venv/bin/activate
gunicorn -k uvicorn.workers.UvicornWorker -w 4 -b 127.0.0.1:8000 app.main:app
```

Recomendado: usar systemd + Nginx.
Archivos ejemplo en:
- `deploy/systemd/restoauto.service`
- `deploy/nginx/restoauto.conf`

---

## URLs
- Landing: `/`
- Panel: `/dashboard`
- Webhook WhatsApp: `POST /webhooks/whatsapp`

---

## Seguridad mínima recomendada
- HTTPS obligatorio
- Tokens/keys solo por ENV
- Logs en servidor (no mostrar errores técnicos al usuario)
- Backups de base de datos

